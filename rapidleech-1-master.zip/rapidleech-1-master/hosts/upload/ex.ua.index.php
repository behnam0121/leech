<?php
$upload_services[]="ex.ua";
$max_file_size["ex.ua"]=100;
$page_upload["ex.ua"] = "ex.ua.php";
?>