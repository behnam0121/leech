<?php
$upload_services[]="uploadmirrors.com";
$max_file_size["uploadmirrors.com"]=100;
$page_upload["uploadmirrors.com"] = "uploadmirrors.com.php";  
?>