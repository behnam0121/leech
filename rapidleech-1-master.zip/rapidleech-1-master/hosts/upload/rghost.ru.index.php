<?php
$upload_services[]="rghost.ru";
$max_file_size["rghost.ru"]=2000;
$page_upload["rghost.ru"] = "rghost.ru.php";
?>