<?php
$upload_services[] = 'uploaded.net_member';
$max_file_size['uploaded.net_member'] = 2000;
$page_upload['uploaded.net_member'] = 'uploaded.net_member.php';
?>