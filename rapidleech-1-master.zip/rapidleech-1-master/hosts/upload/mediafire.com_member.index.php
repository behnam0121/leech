<?php
$upload_services[] = 'mediafire.com_member';
$max_file_size['mediafire.com_member'] = 499; // Set to 20480 after fixing #130
$page_upload['mediafire.com_member'] = 'mediafire.com_member.php';