<?php 
$upload_services[] = "gigasize.com_premium";
$max_file_size["gigasize.com_premium"] = 2000;
$page_upload["gigasize.com_premium"] = "gigasize.com_premium.php";  
?>