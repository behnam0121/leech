<?php
$upload_services[] = 'uploadocean.com';
$max_file_size['uploadocean.com'] = 4096;
$page_upload['uploadocean.com'] = 'uploadocean.com.php';  
?>