<?php
$upload_services[]="share-online.biz_member";
$max_file_size["share-online.biz_member"]=2048;
$page_upload["share-online.biz_member"] = "share-online.biz_member.php";
?>