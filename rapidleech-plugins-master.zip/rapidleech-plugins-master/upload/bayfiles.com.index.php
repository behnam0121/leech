<?php

$upload_services[] = 'bayfiles.com';
$max_file_size['bayfiles.com'] = 10000;
$page_upload['bayfiles.com'] = 'bayfiles.com.php';
