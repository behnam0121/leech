<?php

$upload_services[] = 'transfer.sh';
$max_file_size['transfer.sh'] = 10000;
$page_upload['transfer.sh'] = 'transfer.sh.php';
